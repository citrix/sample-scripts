# Citrix Workspace Fallback Configuration PowerShell Module
Copyright Citrix Systems, Inc. All rights reserved.

## About this module
This PowerShell module enables, for a given Citrix Workspace instance, the configuration of a URL pointing at an on-premises StoreFront Receiver for Web site and an optional friendly title for that site. In the event of an error in Citrix Workspace, the error message will contain a link to the on-premises StoreFront instance. If set, any custom service title will also be shown.

It introduces three cmdlets:

- Get-WorkspaceFallbackConfiguration
- Set-WorkspaceFallbackConfiguration
- Remove-WorkspaceFallbackConfiguration

In order to use the module, an API client ID and secret will need to be generated for the Citrix Cloud customer. See https://developer.cloud.com/getting-started/docs/overview for more information regarding obtaining these credentials.

## System requirements
Windows PowerShell version 5 is the minimum required version. The module has also been confirmed to work on PowerShell 7.0.3.

## Using the module
This module may either be imported directly by passing the path to the `Citrix.Workspace.FallbackConfiguration` directory to the `Import-Module` cmdlet, or by installing the module according to the process specified in PowerShell documentation.

To import the module without installing, from the directory containing this file, run `Import-Module ./Citrix.Workspace.FallbackConfiguration`.

More information and instructions regarding installing and importing PowerShell modules is available by running `Get-Help about_Modules` in a PowerShell session.

Once the module has been imported, help for specific cmdlets can be obtained by running `Get-Help <name of cmdlet> -Full`. For example, `Get-Help Get-WorkspaceFallbackConfiguration -Full`.

## Diagnostics
In the event of issues, `-Verbose` may be supplied to any of the cmdlets in order to produce additional logging.