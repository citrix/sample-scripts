#
# Copyright Citrix Systems, Inc. All rights reserved.
#

#Requires -Version 5
Set-StrictMode -Version 3
$ErrorActionPreference = "Stop"

$DefaultSettings = [PSCustomObject]@{
    "AccountsPath" = "Citrix/Roaming/Accounts";
    "UrlTemplate" = "https://{0}.citrixworkspacesapi.net/";
    "GetTokenPath" = "root/tokens/clients";
    "FallbackConfigsPathTemplate" = "{0}/storeconfigs/{1}/fallbackconfigs"
}

class CitrixWorkspaceFallbackConfiguration {
    [string] $ServiceTitle
    [uri] $StoreWebAddress
}

function BuildUrl {
    param (
        [uri] $BaseUrl,
        [string] $Path
    )

    $builder = New-Object -TypeName "System.UriBuilder" -ArgumentList $BaseUrl
    $builder.Path = $Path

    return $builder.Uri
}

function GetCustomerInfo {
    param (
        [uri] $BaseUrl,
        [guid] $TransactionId
    )

    $settings = GetModuleSettings

    try {
        $accountsUrl = BuildUrl -BaseUrl $BaseUrl -Path $settings.AccountsPath
        $accountsDocument = Invoke-RestMethod -Uri $accountsUrl -Method Get -Headers @{ "Citrix-TransactionId" = $TransactionId.Guid }
    }
    catch {
        Write-Verbose "Error contacting ${BaseUrl}: $_"
        throw "Failed to contact $BaseUrl. Confirm that the URL is accessible using the PowerShell Invoke-WebRequest cmdlet, then try again."
    }

    try {
        $properties = $accountsDocument.accounts.account.details.annotatedServices.annotatedService.metadata.properties.property
    }
    catch {
        Write-Verbose "Error parsing account document: $_"
        throw "Failed to obtain necessary information from $BaseUrl. Confirm that the URL is accessible, then try again."
    }

    $storeGuid = $properties | Where-Object { $_.name -eq 'storeGuid' } | Select-Object -First 1 -ExpandProperty value
    $customerId = $properties | Where-Object { $_.name -eq 'customerId' } | Select-Object -First 1 -ExpandProperty value

    Write-Verbose "StoreGuid = '$storeGuid'; CustomerId = '$customerId'"
    if (-not $storeGuid -or -not $customerId) {
        throw "Failed to obtain necessary information from $BaseUrl. Confirm that the URL is accessible, then try again."
    }

    return [PSCustomObject]@{
        "StoreGuid" = $storeGuid;
        "CustomerId" = $customerId
    }
}

function GetBearerToken {
    param (
        [string] $ClientId,
        [string] $ClientSecret,
        [guid] $TransactionId
    )

    $settings = GetModuleSettings
    $trustBaseUrl = [uri]($settings.UrlTemplate -f "trust")
    $requestTokenUrl = BuildUrl -BaseUrl $trustBaseUrl -Path $settings.GetTokenPath

    $requestBody = @{ "ClientId" = $ClientId; "ClientSecret" = $ClientSecret } | ConvertTo-Json
    try {
        $response = Invoke-RestMethod -Uri $requestTokenUrl -Method Post -UseBasicParsing -Body $requestBody -ContentType "application/json" -Headers @{ "X-Cws-TransactionId" = $TransactionId.Guid }
    }
    catch {
        Write-Verbose "Error obtaining Citrix Cloud bearer token: $_"
        throw "There was an error contacting the Citrix Cloud Trust service to obtain a bearer token."
    }

    try {
        $bearerToken = "CWSAuth bearer=$($response.token)"
    }
    catch {
        Write-Verbose "Error obtaining token from Trust response: $_"
        throw "The response from the Citrix Cloud Trust service was not of the expected format."
    }

    Write-Verbose "Bearer token has length $($bearerToken.Length)"
    return $bearerToken
}

function GetModuleSettings {
    if ($env:CTXSWSPOSHSETTINGS -and (Test-Path $env:CTXSWSPOSHSETTINGS -ErrorAction SilentlyContinue)) {
        Write-Verbose "Using custom settings defined in $($env:CTXSWSPOSHSETTINGS)"
        return [PSCustomObject](Get-Content $env:CTXSWSPOSHSETTINGS | ConvertFrom-Json)
    }
    else {
        Write-Debug "Using default settings object"
        return $Script:DefaultSettings
    }
}

function MakeFallbackConfigsUrl {
    param (
        [string] $CustomerId,
        [string] $StoreGuid
    )

    $settings = GetModuleSettings
    $baseUrl = $settings.UrlTemplate -f "storefrontconfiguration"
    $path = $settings.FallbackConfigsPathTemplate -f $CustomerId, $StoreGuid

    return BuildUrl -BaseUrl $baseUrl -Path $path
}

function ConvertFallbackConfigsResponse {
    param (
        $Response
    )

    Write-Debug "ConvertFallbackConfigsResponse: Response is: $Response"

    if ($null -eq $Response -or "null" -eq $Response) {
        return @()
    }
    elseif ($Response -is [array]) {
        return @($Response | ConvertFallbackConfigurationResponse)
    }
    else {
        Write-Verbose "Unexpected response. Type of response is $($Response.GetType())"
        throw "The response received when retrieving the configuration was not of the expected format."
    }
}

function ConvertFallbackConfigurationResponse {
    param (
        [Parameter(ValueFromPipeline)]
        $Response
    )

    process {
        $result = [CitrixWorkspaceFallbackConfiguration]::new()

        Write-Debug "ConvertFallbackConfigurationResponse: Response is: $Response"

        # Allows `{}`, but otherwise must contain the properties listed.
        if ($Response -is [PSCustomObject] -and `
                ((-not [Linq.Enumerable]::Any($Response.PSObject.Properties)) -or `
                $Response.PSObject.Properties.Name -contains "fallbackServiceTitle" -or `
                $Response.PSObject.Properties.Name -contains "fallbackAddresses")) {
            Write-Debug "Response is a PSCustomObject"
            if ($Response.PSObject.Properties.Name -contains "fallbackServiceTitle") {
                Write-Debug "Adding ServiceTitle"
                $result.ServiceTitle = $Response.fallbackServiceTitle
            }

            if ($Response.PSObject.Properties.Name -contains "fallbackAddresses" -and `
                    $Response.fallbackAddresses -is [PSCustomObject] -and `
                    $Response.fallbackAddresses.PSObject.Properties.Name -contains "storeWeb") {
                Write-Debug "Adding StoreWebAddress"
                $result.StoreWebAddress = $Response.fallbackAddresses.storeWeb
            }
        }
        elseif ($null -eq $Response) {
            Write-Debug "Response is null"
        }
        else {
            Write-Verbose "Unexpected response. Type of response is $($Response.GetType())"
            throw "The response received when retrieving the configuration was not of the expected format."
        }

        Write-Output $result
    }
}

function ValidateUrl {
    param (
        [uri] $Url,
        [switch] $AllowHttp
    )

    if ($null -ne $Url -and $Url.IsAbsoluteUri -and (($AllowHttp -and $Url.Scheme -eq "http") -or $Url.Scheme -eq "https")) {
        return $true
    }
    else {
        if ($AllowHttp) {
            throw "HTTP/HTTPS URL is required (e.g. https://wwco.cloud.com)."
        } else {
            throw "HTTPS URL is required (e.g. https://wwco.cloud.com)."
        }
    }
}

function ValidateTitle {
    param (
        [string] $Title
    )

    if ($Title -cnotmatch "^[\w.-][\w .-]{0,29}$") {
        throw "Invalid title. Check that the title does not contain special characters and is less than 30 characters in length."
    }
    else {
        return $true
    }
}

function ValidateConfiguration {
    param (
        [CitrixWorkspaceFallbackConfiguration[]] $Configuration
    )

    foreach ($config in $Configuration) {
        try {
            ValidateUrl -Url $config.StoreWebAddress | Out-Null
        }
        catch {
            throw "Error validating StoreWebAddress $($config.StoreWebAddress): $_"
        }

        try {
            if (-not ([string]::IsNullOrEmpty($config.ServiceTitle))) {
                ValidateTitle -Title $config.ServiceTitle | Out-Null
            }
        }
        catch {
            throw "Error validating ServiceTitle $($config.ServiceTitle): $_"
        }
    }

    return $true
}

function NewTransactionId {
    $transactionId = New-Guid
    Write-Verbose "Transaction ID: $transactionId"

    return $transactionId
}

function StringsEmptyOrEqual {
    param (
        $A,
        $B
    )

    return ([string]::IsNullOrEmpty($A) -and [string]::IsNullOrEmpty($B)) -or ($A -eq $B)
}

function ValidateConfigurationResponse {
    param (
        [CitrixWorkspaceFallbackConfiguration[]] $Response,
        [CitrixWorkspaceFallbackConfiguration[]] $ExpectedConfiguration
    )

    $expectedConfigurationCount = 0
    if ($null -ne $ExpectedConfiguration) {
        $expectedConfigurationCount = $ExpectedConfiguration.Count
    }

    $responseCount = 0
    if ($null -ne $Response) {
        $responseCount = $Response.Count
    }

    $isEqual = $expectedConfigurationCount -eq $responseCount

    for ($i = 0; $i -lt $expectedConfigurationCount -and $isEqual; $i++) {
        $isEqual = $isEqual -and (StringsEmptyOrEqual $ExpectedConfiguration[$i].StoreWebAddress $Response[$i].StoreWebAddress -and StringsEmptyOrEqual $ExpectedConfiguration[$i].ServiceTitle $Response[$i].ServiceTitle)
    }

    return $isEqual
}

<#
    .SYNOPSIS
        Retrieves the currently configured on-premises StoreFront URLs and titles for your Citrix Workspace.

    .DESCRIPTION
        Retrieves the currently configured on-premises StoreFront URLs and titles for your Citrix Workspace. If Workspace becomes unavailable and at least one URL has been set, the error message will contain a link to the on-premises StoreFront instance. If set, the corresponding custom service title for each URL will also be displayed.

    .PARAMETER WorkspaceUrl
        The URL used to access your Citrix Workspace, in the format of https://<yourcustomer>.cloud.com. Example: "https://wwco.cloud.com"

    .PARAMETER ClientId
        An API key for the Citrix Cloud deployment, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .PARAMETER ClientSecret
        The corresponding secret key for the API key, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .INPUTS
        None

    .OUTPUTS
        CitrixWorkspaceFallbackConfiguration
        An object with two properties, representing the current configuration set for your Citrix Workspace instance:

        * ServiceTitle (string): The friendly service title. Will be null if not set.
        * StoreWebAddress (string): The URL used to access your on-premises StoreFront Receiver for Web site. Will be null if not set.

    .EXAMPLE
        PS> Get-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm=="

        ServiceTitle         StoreWebAddress
        ------------         ---------------
        WWCo StoreFront US   https://wwcostorefront-us.example.com/Citrix/StoreWeb/
        WWCo StoreFront EMEA https://wwcostorefront-emea.example.com/Citrix/StoreWeb/
        WWCo StoreFront APAC https://wwcostorefront-apac.example.com/Citrix/StoreWeb/

    .LINK
        Set-WorkspaceFallbackConfiguration

    .LINK
        Remove-WorkspaceFallbackConfiguration
#>
function Get-WorkspaceFallbackConfiguration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateScript({ValidateUrl $_})]
        [uri] $WorkspaceUrl,

        [Parameter(Mandatory = $true)]
        [string] $ClientId,

        [Parameter(Mandatory = $true)]
        [string] $ClientSecret
    )

    $transactionId = NewTransactionId

    $customerInfo = GetCustomerInfo -BaseUrl $WorkspaceUrl -TransactionId $transactionId
    $bearerToken = GetBearerToken -ClientId $ClientId -ClientSecret $ClientSecret -TransactionId $transactionId
    $configurationUrl = MakeFallbackConfigsUrl -CustomerId $customerInfo.CustomerId -StoreGuid $customerInfo.StoreGuid

    try {
        [array]$response = Invoke-RestMethod -Uri $configurationUrl -Method Get -UseBasicParsing -Headers @{ "Authorization" = $bearerToken; "X-Cws-TransactionId" = $transactionId.Guid }
    }
    catch {
        Write-Verbose "Error obtaining fallback configuration: $_"
        throw "There was an error obtaining the fallback configuration."
    }

    return ConvertFallbackConfigsResponse -Response $response
}

<#
    .SYNOPSIS
        Configures one or more on-premises StoreFront URLs and optional titles for your Citrix Workspace, which are displayed to end users when Workspace is temporarily unavailable.

    .DESCRIPTION
        Configures one or more on-premises StoreFront URLs and optional titles for your Citrix Workspace, which are displayed to end users as links when Workspace is temporarily unavailable.
        When any URLs are set, the error message displayed to the end user will contain links to the configured StoreFront URLs. Any existing configuration is overwritten when this command is run.

    .PARAMETER WorkspaceUrl
        The URL used to access your Citrix Workspace, in the format of https://<yourcustomer>.cloud.com. Example: "https://wwco.cloud.com"

    .PARAMETER ClientId
        An API key for the Citrix Cloud deployment, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .PARAMETER ClientSecret
        The corresponding secret key for the API key, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .PARAMETER StoreWebAddress
        The URL for accessing your on-premises StoreFront deployment (Receiver for Web site) such as https://<yourstorefront>.example.com.
        Relevant error messages displayed to end users within Workspace will contain a link pointing at this URL.
        When supplying multiple StoreFront URLs and titles, use the Configuration parameter instead.

    .PARAMETER ServiceTitle
        A friendly name for the StoreFront deployment. Example: "WWCo StoreFront"
        When supplying multiple StoreFront URLs and titles, use the Configuration parameter instead.

    .PARAMETER Configuration
        The fallback configuration. This may be specified as an array of hashtables containing two elements: ServiceTitle and StoreWebAddress.
        Relevant error messages displayed to end users within Workspace will contain links pointing at the URLs given.

    .INPUTS
        None

    .OUTPUTS
        CitrixWorkspaceFallbackConfiguration
        An object with two properties, representing the current configuration set for your Citrix Workspace instance:

        * ServiceTitle (string): The friendly service title. Will be null if not set.
        * StoreWebAddress (string): The URL used to access your on-premises StoreFront Receiver for Web site. Will be null if not set.

    .EXAMPLE
        PS> Set-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm==" -StoreWebAddress "https://wwcostorefront.example.com/Citrix/StoreWeb/" -ServiceTitle "WWCo StoreFront"

        ServiceTitle    StoreWebAddress
        ------------    ---------------
        WWCo StoreFront https://wwcostorefront.example.com/Citrix/StoreWeb/

    .EXAMPLE
        PS> Set-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm==" -StoreWebAddress "https://wwcostorefront.example.com/Citrix/StoreWeb/"
        
        ServiceTitle StoreWebAddress
        ------------ ---------------
                     https://wwcostorefront.example.com/Citrix/StoreWeb/

    .EXAMPLE
        PS> Set-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm==" -Configuration @{ "ServiceTitle" = "WWCo StoreFront US"; "StoreWebAddress" = "https://wwcostorefront-us.example.com/Citrix/StoreWeb/" }, @{ "ServiceTitle" = "WWCo StoreFront EMEA"; "StoreWebAddress" = "https://wwcostorefront-emea.example.com/Citrix/StoreWeb/" }

        ServiceTitle         StoreWebAddress
        ------------         ---------------
        WWCo StoreFront US   https://wwcostorefront-us.example.com/Citrix/StoreWeb/
        WWCo StoreFront EMEA https://wwcostorefront-emea.example.com/Citrix/StoreWeb/

    .EXAMPLE
        PS> $config = Get-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm=="
        PS> $config

        ServiceTitle         StoreWebAddress
        ------------         ---------------
        WWCo StoreFront US   https://wwcostorefront.example.com/Citrix/StoreWeb/
        WWCo StoreFront EMEA https://wwcostorefront-emea.example.com/Citrix/StoreWeb/

        PS> $config[0].ServiceTitle = "WWCo StoreFront Americas"
        PS> Set-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm==" -Configuration $config

        ServiceTitle             StoreWebAddress
        ------------             ---------------
        WWCo StoreFront Americas https://wwcostorefront.example.com/Citrix/StoreWeb/
        WWCo StoreFront EMEA     https://wwcostorefront-emea.example.com/Citrix/StoreWeb/

    .LINK
        Get-WorkspaceFallbackConfiguration

    .LINK
        Remove-WorkspaceFallbackConfiguration
#>
function Set-WorkspaceFallbackConfiguration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true, ParameterSetName = "Single")]
        [Parameter(Mandatory = $true, ParameterSetName = "Multiple")]
        [ValidateScript({ValidateUrl $_})]
        [uri] $WorkspaceUrl,

        [Parameter(Mandatory = $true, ParameterSetName = "Single")]
        [Parameter(Mandatory = $true, ParameterSetName = "Multiple")]
        [string] $ClientId,

        [Parameter(Mandatory = $true, ParameterSetName = "Single")]
        [Parameter(Mandatory = $true, ParameterSetName = "Multiple")]
        [string] $ClientSecret,

        [Parameter(Mandatory = $true, ParameterSetName = "Multiple")]
        [ValidateScript({ValidateConfiguration -Configuration $_})]
        [CitrixWorkspaceFallbackConfiguration[]] $Configuration,

        [Parameter(Mandatory = $true, ParameterSetName = "Single")]
        [ValidateScript({ValidateUrl -Url $_ -AllowHttp})]
        [string] $StoreWebAddress,

        [Parameter(Mandatory = $false, ParameterSetName = "Single")]
        [ValidateScript({ValidateTitle -Title $_})]
        [string] $ServiceTitle
    )

    if ($PSCmdlet.ParameterSetName -eq "Single") {
        Write-Debug "Single configuration mode"
        $singleConfig = [CitrixWorkspaceFallbackConfiguration]::new()
        $singleConfig.StoreWebAddress = $StoreWebAddress
        if ($ServiceTitle) {
            $singleConfig.ServiceTitle = $ServiceTitle
        }

        $Configuration = @($singleConfig)
    }

    $transactionId = NewTransactionId

    $customerInfo = GetCustomerInfo -BaseUrl $WorkspaceUrl -TransactionId $transactionId
    $bearerToken = GetBearerToken -ClientId $ClientId -ClientSecret $ClientSecret -TransactionId $transactionId
    $configurationUrl = MakeFallbackConfigsUrl -CustomerId $customerInfo.CustomerId -StoreGuid $customerInfo.StoreGuid

    $requestBody = @($Configuration | ForEach-Object {
        $config = @{ "fallbackAddresses" = @{ "StoreWeb" = $_.StoreWebAddress } }
        if ($_.ServiceTitle) {
            $config["fallbackServiceTitle"] = $_.ServiceTitle
        }
        $config
    })

    $requestJson = ConvertTo-Json -InputObject $requestBody
    Write-Debug "JSON: $requestJson"

    $requestUtf8Bytes = [System.Text.Encoding]::UTF8.GetBytes($requestJson)

    try {
        [array]$response = Invoke-RestMethod -Uri $configurationUrl -Method Put -UseBasicParsing -Headers @{ "Authorization" = $bearerToken; "X-Cws-TransactionId" = $transactionId.Guid } -Body $requestUtf8Bytes -ContentType "application/json"
    }
    catch {
        Write-Verbose "Error updating fallback configuration: $_"
        throw "There was an error updating the fallback configuration."
    }

    $convertedResponse = ConvertFallbackConfigsResponse -Response $response

    if (-not (ValidateConfigurationResponse -Response $convertedResponse -ExpectedConfiguration $Configuration)) {
        throw "An unexpected fallback configuration has been returned when updating the configuration." + `
            "`n$($convertedResponse | Out-String)" + `
            "`nCheck that the configuration has been updated by calling Get-WorkspaceFallbackConfiguration."
    }

    return $convertedResponse
}

<#
    .SYNOPSIS
        Removes any previously configured on-premises StoreFront URLs and titles from your Citrix Workspace.

    .DESCRIPTION
        Removes the fallback configuration from your Citrix Workspace, such that any on-premises StoreFront URLs configured previously are removed. If Workspace becomes unavailable, the error message will no longer contain any link to an on-premises StoreFront instance.

    .PARAMETER WorkspaceUrl
        The URL used to access your Citrix Workspace, in the format of https://<yourcustomer>.cloud.com. Example: "https://wwco.cloud.com"

    .PARAMETER ClientId
        An API key for the Citrix Cloud deployment, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .PARAMETER ClientSecret
        The corresponding secret key for the API key, generated using 'Identity and Access Management' on the Citrix Cloud website. See https://developer.cloud.com/getting-started/docs/overview for more information.

    .INPUTS
        None

    .OUTPUTS
        CitrixWorkspaceFallbackConfiguration
        An object with two properties, representing the current configuration set for your Citrix Workspace instance:

        * ServiceTitle (string): The friendly service title. Will be null if not set.
        * StoreWebAddress (string): The URL used to access your on-premises StoreFront Receiver for Web site. Will be null if not set.

    .EXAMPLE
        PS> Remove-WorkspaceFallbackConfiguration -WorkspaceUrl "https://wwco.cloud.com" -ClientId "24242111-05b9-04aa-86bc-7251b18f4c59" -ClientSecret "1c787hjmpdAWkNIcT2CSlkm=="

        ServiceTitle StoreWebAddress
        ------------ ---------------

    .LINK
        Get-WorkspaceFallbackConfiguration

    .LINK
        Set-WorkspaceFallbackConfiguration
#>
function Remove-WorkspaceFallbackConfiguration {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [ValidateScript({ValidateUrl $_})]
        [uri] $WorkspaceUrl,

        [Parameter(Mandatory = $true)]
        [string] $ClientId,

        [Parameter(Mandatory = $true)]
        [string] $ClientSecret
    )

    $transactionId = NewTransactionId

    $customerInfo = GetCustomerInfo -BaseUrl $WorkspaceUrl -TransactionId $transactionId
    $bearerToken = GetBearerToken -ClientId $ClientId -ClientSecret $ClientSecret -TransactionId $transactionId
    $configurationUrl = MakeFallbackConfigsUrl -CustomerId $customerInfo.CustomerId -StoreGuid $customerInfo.StoreGuid

    try {
        [array]$response = Invoke-RestMethod -Uri $configurationUrl -Method Put -UseBasicParsing -Headers @{ "Authorization" = $bearerToken; "X-Cws-TransactionId" = $transactionId.Guid }
    }
    catch {
        Write-Verbose "Error updating fallback configuration: $_"
        throw "There was an error updating the fallback configuration."
    }

    $convertedResponse = ConvertFallbackConfigsResponse -Response $response

    if (-not (ValidateConfigurationResponse -Response $convertedResponse -ExpectedConfiguration $null)) {
        throw "A non-empty fallback configuration has been returned when removing the configuration." + `
            "`nStoreWebAddress = '$($convertedResponse.StoreWebAddress)'; ServiceTitle = '$($convertedResponse.ServiceTitle)'" + `
            "`nCheck that the configuration has been cleared by calling Get-WorkspaceFallbackConfiguration."
    }

    return $convertedResponse
}

Export-ModuleMember -Function Get-WorkspaceFallbackConfiguration, Set-WorkspaceFallbackConfiguration, Remove-WorkspaceFallbackConfiguration
# SIG # Begin signature block
# MIINagYJKoZIhvcNAQcCoIINWzCCDVcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDWOF2DZtkaz5gx
# WERrIxJCs7dSIXuVZaQIRaRbqg/5zqCCCpAwggUwMIIEGKADAgECAhAECRgbX9W7
# ZnVTQ7VvlVAIMA0GCSqGSIb3DQEBCwUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0xMzEwMjIxMjAwMDBa
# Fw0yODEwMjIxMjAwMDBaMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lD
# ZXJ0IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQD407Mcfw4Rr2d3B9MLMUkZz9D7RZmxOttE9X/l
# qJ3bMtdx6nadBS63j/qSQ8Cl+YnUNxnXtqrwnIal2CWsDnkoOn7p0WfTxvspJ8fT
# eyOU5JEjlpB3gvmhhCNmElQzUHSxKCa7JGnCwlLyFGeKiUXULaGj6YgsIJWuHEqH
# CN8M9eJNYBi+qsSyrnAxZjNxPqxwoqvOf+l8y5Kh5TsxHM/q8grkV7tKtel05iv+
# bMt+dDk2DZDv5LVOpKnqagqrhPOsZ061xPeM0SAlI+sIZD5SlsHyDxL0xY4PwaLo
# LFH3c7y9hbFig3NBggfkOItqcyDQD2RzPJ6fpjOp/RnfJZPRAgMBAAGjggHNMIIB
# yTASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAK
# BggrBgEFBQcDAzB5BggrBgEFBQcBAQRtMGswJAYIKwYBBQUHMAGGGGh0dHA6Ly9v
# Y3NwLmRpZ2ljZXJ0LmNvbTBDBggrBgEFBQcwAoY3aHR0cDovL2NhY2VydHMuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNydDCBgQYDVR0fBHow
# eDA6oDigNoY0aHR0cDovL2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJl
# ZElEUm9vdENBLmNybDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDBPBgNVHSAESDBGMDgGCmCGSAGG/WwA
# AgQwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGlnaWNlcnQuY29tL0NQUzAK
# BghghkgBhv1sAzAdBgNVHQ4EFgQUWsS5eyoKo6XqcQPAYPkt9mV1DlgwHwYDVR0j
# BBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDQYJKoZIhvcNAQELBQADggEBAD7s
# DVoks/Mi0RXILHwlKXaoHV0cLToaxO8wYdd+C2D9wz0PxK+L/e8q3yBVN7Dh9tGS
# dQ9RtG6ljlriXiSBThCk7j9xjmMOE0ut119EefM2FAaK95xGTlz/kLEbBw6RFfu6
# r7VRwo0kriTGxycqoSkoGjpxKAI8LpGjwCUR4pwUR6F6aGivm6dcIFzZcbEMj7uo
# +MUSaJ/PQMtARKUT8OZkDCUIQjKyNookAv4vcn4c10lFluhZHen6dGRrsutmQ9qz
# sIzV6Q3d9gEgzpkxYz0IGhizgZtPxpMQBvwHgfqL2vmCSfdibqFT+hKUGIUukpHq
# aGxEMrJmoecYpJpkUe8wggVYMIIEQKADAgECAhACtjPjVpS7sI1rVZfQwWjuMA0G
# CSqGSIb3DQEBCwUAMHIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJ
# bmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0
# IFNIQTIgQXNzdXJlZCBJRCBDb2RlIFNpZ25pbmcgQ0EwHhcNMjAxMjE3MDAwMDAw
# WhcNMjIxMjIxMjM1OTU5WjCBlDELMAkGA1UEBhMCVVMxEDAOBgNVBAgTB0Zsb3Jp
# ZGExGDAWBgNVBAcTD0ZvcnQgTGF1ZGVyZGFsZTEdMBsGA1UEChMUQ2l0cml4IFN5
# c3RlbXMsIEluYy4xGzAZBgNVBAsTEkNpdHJpeCBTSEEyNTYgMjAyMTEdMBsGA1UE
# AxMUQ2l0cml4IFN5c3RlbXMsIEluYy4wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCx96xdpEhKlFDpsTVNZD1u+tcPGhaoXUnnus9iseWeL/hKudLfduZA
# rCm3oUxq8NTGofqF5qGZuWNIyAzP/Bu8Usj6cjV06M89aTtphr3BfvSEi2iHVRJv
# +5/H39V/osC2aDw1seUCWgDZYG6tEr/kUjiOjFvW5uNCsxeUYNjn2+8r/VJMSb76
# NVM3rrpwXL2ZKHkfse3D4EWInZoy51yJNBiR0L8U1BMOQezWVCI/8hDW8gD/3aTn
# rjlCQ0nDXEQNyra5gZe06NHd8xKL+bN0S3NavqqlB5c+mwxldOYsyat880aOkahY
# CuH/Ck/3pcgHv/Q9jRhM9vwAS7hq7l53AgMBAAGjggHFMIIBwTAfBgNVHSMEGDAW
# gBRaxLl7KgqjpepxA8Bg+S32ZXUOWDAdBgNVHQ4EFgQUiHLAjjWlJdiBcVBgaOyJ
# G+GPyjYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGA1Ud
# HwRwMG4wNaAzoDGGL2h0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEyLWFzc3Vy
# ZWQtY3MtZzEuY3JsMDWgM6Axhi9odHRwOi8vY3JsNC5kaWdpY2VydC5jb20vc2hh
# Mi1hc3N1cmVkLWNzLWcxLmNybDBMBgNVHSAERTBDMDcGCWCGSAGG/WwDATAqMCgG
# CCsGAQUFBwIBFhxodHRwczovL3d3dy5kaWdpY2VydC5jb20vQ1BTMAgGBmeBDAEE
# ATCBhAYIKwYBBQUHAQEEeDB2MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wTgYIKwYBBQUHMAKGQmh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydFNIQTJBc3N1cmVkSURDb2RlU2lnbmluZ0NBLmNydDAMBgNVHRMB
# Af8EAjAAMA0GCSqGSIb3DQEBCwUAA4IBAQA2pq9oypTNWRp3MiDVDARsf9vwJ+m5
# blRsnL5IQk9NN5/eaYl0Q0h5jRUTDWOMA7BACtvZaHgfs7PyqBMhklXIs7SY3n2D
# BjzZr8Bx3u4TLTDyO1+cww+96VfPZeE6so2y3MYPTXVmu78fn4uGlbG1TeTwjCn5
# xH3YB4quyVG4bdiu7Gvb8wkz7Vn8YzQg807fWJHYNfuysoO3ecgDMAz2P1yyXjvv
# 87MdjrDikvZI5bk1KqGAPrx9abMIx/CS2Gb9UkLLTsDQWiuZzqcmbSvb3NN5xQTp
# qgciCeWB12g5rHtMyRnAIRVtb573Fdk8ASUJuMxxV8vQ2I3A4dXnG/PYMYICMDCC
# AiwCAQEwgYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZ
# MBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hB
# MiBBc3N1cmVkIElEIENvZGUgU2lnbmluZyBDQQIQArYz41aUu7CNa1WX0MFo7jAN
# BglghkgBZQMEAgEFAKB8MBAGCisGAQQBgjcCAQwxAjAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCdHdpC6yZo7FHca93tOFNpejucixKRcVpkYbLdfHUrDzANBgkq
# hkiG9w0BAQEFAASCAQBmSZAMkouRAoUE6645TefbeeXV5KGmOareCR4vwitVBLkd
# Esot+elM0CtXq7uot9YaSdw8M/C+SBKWmv22QpGM3rdCXOYOO0d9+C8wQYM5BD38
# dt5WDdCBgQxkzjK6YjfURr2DMiWSJ/239ICIOHji3t2X2kcDIjYgQk/5BPV4jgio
# fAp+2b+G83wn+Jfi0xd/DcY4EpTlwf7xk6rgrFEGWAX/wZmSKGNFNFy/b1MRv43u
# NbRBkBbVcSorv/i2F0jBBXP/76+RHHqpg7rTO7IoSqEbDq7ovl0BjgDvznHmp9lf
# Kf691+4QDAK/t56CrkkxtcG8M7CVG/cYugR/vXyk
# SIG # End signature block
